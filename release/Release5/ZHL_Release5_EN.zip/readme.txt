=========================
ZHL
=========================

You are Tod Connor, a deliveryman working for ZHL, a multi-planetary package pickup and delivery company in the 24th century. You have been tasked with picking up a mysterious package from a warehouse on one of Jupiter's satellites. A simple job got complicated.

A science fiction tale created by KMBR

Release 5
Acknowledgements to aa@zdk.org and Carlos Sánchhez (UTO)
Reynolds font by DamienG https://damieng.com/zx-origins 
ZX7 graphics compression written by Einar Saukas 
Compiled on Z88DK v1.99b

This work is under a CC BY-NC-ND  Attribution-NonCommercial-NoDerivs License
https://creativecommons.org/licenses/by-nc-nd/4.0/ 

(c) 2019,2021 KMBR 

03th April 2021, KMBR

