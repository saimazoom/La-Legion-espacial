=========================
ZHL
=========================

Eres Tod Connor un repartidor que trabaja para ZHL, una empresa multiplanetaria de recogida y entrega de paquetes en el siglo XXIV. Has recibido el encargo de recoger un misterioso paquete de un almacén en uno de los satélites de Júpiter. Pero todo se complica.

Una aventura de ciencia ficción creada por KMBR

Release 4
Agradecimientos a aa@zdk.org y Carlos Sánchhez (UTO)
Reynolds font by DamienG https://damieng.com/zx-origins 
Compresión de gráficos con ZX7 lib escrita por Einar Saukas 
Compilado en Z88DK v1.99b

This work is under a CC BY-NC-ND  Attribution-NonCommercial-NoDerivs License
https://creativecommons.org/licenses/by-nc-nd/4.0/ 

(c) 2019 KMBR 

31th December 2019, KMBR

